# Web City RPG

A lightweight, mobile-friendly, fan-made Spider-Man-inspired RPG for basic Android phones.

## Run
Open `index.html` in a browser, or publish the repository with GitHub Pages. The manifest and service worker make it installable/offline-capable when served over HTTPS.

## GitHub Pages
1. Upload all files to the root of your repository.
2. In GitHub: **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select the default branch and `/ (root)`, then Save.
5. Open the Pages URL GitHub gives you on your Android phone.

Fan-made project; not affiliated with or endorsed by Marvel or Sony.
